%%a)
clc; clf; clear all
d=14;
m=21;
a=ones(1,d+1);
x=linspace(0,1,m);
y = polyval(a,x);

%y=zeros(1,m)
%for i=1:1:m
%    y(i) = polyval(a,x(i))
%end


%b)
%The columns in A are powers of the vector x. Column1 is x^1, 2 is x^2 and
%so forth

A = fliplr(vander(x));


%1) Using normal equations: A'A� =A'y
ahat1 = linsolve(A'*A,A'*y');
%ahat1p=(A'*A)\(A'*y');
%ahat1_lsq =lsqnonneg(A,y')
a=ones(1,m);



err1=norm(ahat1-a')
%err1p=norm(ahat1p-a')

%2) using QR-factorization
%Want to minimize the residual, which is minimized when Rx=Q1'b
[Q,R] = qr(A);

ahat2 = linsolve(R,Q'*y');
err2=norm(ahat2-a')


%3) truncated least-squares using 12 terms of SVD
%12 terms of SVD means that we study an approximation to A.

[U,S,V]=svd(A);
sigma=zeros(12,1);

Ak=zeros(length(A),21);
for i=1:1:12
    B=find(S,i);
    sigma(i)=S(B(i));
    Ak=Ak+sigma(i).*U(:,i)*V(:,i)';
end

Aplusk=pinv(Ak);
ahat3=Aplusk*y';

err3=norm(ahat3-a')

%Test with SVDS in matlab. Gives the same result
[A,B,C]=svds(A,12);

ahat3prim=C*inv(B)*A'*y';
err3prim=norm(ahat3prim-a')









