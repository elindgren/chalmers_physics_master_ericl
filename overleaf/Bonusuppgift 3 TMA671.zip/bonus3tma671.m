clear all; clf; clc;
%a)
REGION = 'S';
n=13;
p=6;
tol=1e-6;

G=numgrid(REGION,n);
subplot(2,1,1)
spy(G)
title('121x121')

subplot(2,1,2)
D=delsq(G);
spy(D)
title('Five-point Laplacian')

%*********************************** a *******************************%
tic
%The eigenvalues from D are given as
Deig=eig(D);
DeigRef=zeros(p,1);

%A=zeros(length(D),p);
X0=zeros(length(D),p);

for i=1:1:p
    MAX=max(Deig);
    DeigRef(i)=MAX;
    [r]=find(abs(Deig-MAX)<tol);
    %If multiple identical
    if length(r)==2
        r=r(1);
    end
    Deig(r)=Deig(r)-MAX;
    X0(i,i)=1;
end

%Calculating the largest eigenvalues using 

%Orthogonal iteration

%In this example we have X0=I, a matrix with n rows and the p first
%columns of I.
A=D;
eigp=rand(1,p);
eigp1=rand(1,p);
X=X0;
i=1;
%abs(sum(eigp)-sum(DeigRef))
while norm(eigp1-eigp)>tol
   eigp=eigp1; %The eigenvalues from the last iteration are brought over

   [Q,Ri,P]=qr(X);
   X=A*Q;
   
   %sorting out the six largest digaonal values in Ri (converges towards the
   %six largest eigenvalues). This speeds up the process of finding the
   %largest eigenvalues, as the matrix Ri diagonal converges to
   %lambda1,...,lambdan, where lambda1 is the largest. This is due to us
   %using [Q,R,E]=qr(A) in matlab, where E is the permutation matrix that
   %gives Ri this desired shape. 
   
   x=diag(Ri);
   for j=1:1:p
       eigp1(j)=x(j);
   end
   i=i+1;
end
%R1 contains the eigenvalues, on the diagonal
t1=toc
iter1=i
'The six largest eigenvalues are:'
disp(eigp')

%************************************* c *******************************%

tic
%We want to invert the matrix D. We do this once using a
%choleskyfactorization, D=R'*R (Chol produces the upper triangular matrix).
%This works due to the eigenvalues of A-1 being lambda-1. That is, the
%largest eigenvalues calculated are the smallest.

[R]=chol(D);

Rinv=inv(R);
%Only using Dinv for generating the eigenvalues to compare against
Dinv=Rinv*Rinv';

%Using the same algorithm as above

%The eigenvalues from Dinv are given as
Deig=eigs(Dinv);
DeigRef=zeros(p,1);

X=zeros(length(D),p);

for i=1:1:p
    MAX=max(Deig);
    DeigRef(i)=MAX;
    [r]=find(abs(Deig-MAX)<0.0001);
    %If multiple identical
    if length(r)==2
        r=r(1);
    end
    Deig(r)=Deig(r)-MAX;
    X(i,i)=1;
end

%Calculating the smallest eigenvalues using 
%Orthogonal iteration. The we are still looking for the maximum eigenvalues
%of the inverted matrix, as the smallest eigenvalues of D become the
%largest of D^-1, as they are inverted. 


i=1;
%A=Dinv;
eigp=rand(1,p);
eigp1=rand(1,p);
while norm(eigp1-eigp)>tol
   eigp=eigp1;
   [Q,Ri,P]=qr(X);
   Z=R'\Q;
   X=R\Z;

   x=diag(Ri);
   for j=1:1:p
       eigp1(j)=x(j);
   end
   i=i+1;
end

%the eigenvalues have been calculated
t2=toc
iter2=i
'The six smallest eigenvalues are:'
for i=1:1:p
    disp(1/eigp1(i))
end



