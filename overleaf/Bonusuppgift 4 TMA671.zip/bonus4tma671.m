%%uppgift a)
clc; clear all; clf;
n=13;
normx = zeros(1,n);
normr = zeros(1,n);
kond  = zeros(1,n);
for i=1:1:n
    H=hilb(i);
    x=ones(i,1);
    b=H*x;
    %First column of the output of xhat is the iteration
    xhat = b'/H;
    errx = xhat'-x;
    res = b-(H*xhat');
    %Plotting the norm of the error and of the residual, using norm in
    %matlab (the 2-norm)
    normx(i) = norm(errx);
    normr(i) = norm(res);
    kond(i)= cond(H);
end
% t=linspace(0,n,n);
% subplot(3,1,1)
% plot(t,(normx),'b')
% subplot(3,1,2)
% plot(t,normr,'g')
% subplot(3,1,3);
% plot(t,kond,'r')

t=linspace(0,n,n);
subplot(6,1,1)
plot(t,(normx),'b')
title('Norm av det absoluta felet, ej logaritmerat')
subplot(6,1,2)
plot(t,log(normx),'b')
title('norm av fel, logaritmerat')
subplot(6,1,3);
plot(t,kond,'r')
title('konditionstal, ej logaritmerat')
subplot(6,1,4)
plot(t,log(kond),'r')
title('konditionstal, logaritmerat')
subplot(6,1,5)
plot(t,normr,'g')
title('Residual, ej logaritmerad')
subplot(6,1,6)
plot(t,log(normr),'g')
title('Residual, logaritmerad')
format long