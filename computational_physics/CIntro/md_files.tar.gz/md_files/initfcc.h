/*
initfcc.h

Created by Anders Lindman on 2013-03-15.
*/

#ifndef _initfcc_h
#define _initfcc_h

extern void init_fcc(double[][3], int, double);


#endif
